import firebase from 'firebase'
require("@firebase/firestore")

const firebaseConfig = {
  apiKey: "AIzaSyCxxjvtQafnKEzU2Zw76ofiji8MCE09iho",
  authDomain: "projectc71-3af45.firebaseapp.com",
  projectId: "projectc71-3af45",
  storageBucket: "projectc71-3af45.appspot.com",
  messagingSenderId: "12144407382",
  appId: "1:12144407382:web:fabf1f942a1b1a41161cf7"
};
  firebase.initializeApp(firebaseConfig);

  export default firebase.firestore()

